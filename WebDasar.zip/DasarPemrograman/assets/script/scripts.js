const mobileNav = document.querySelector(".hamburger");
const navbar = document.querySelector(".menubar");

const toggleNav = () => {
  navbar.classList.toggle("active");
  mobileNav.classList.toggle("hamburger-active");
};
mobileNav.addEventListener("click", () => toggleNav());

window.onscroll = function () {
  const topButton = document.getElementById("topBotton");
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    topButton.classList.add("show");
  } else {
    topButton.classList.remove("show");
  }
};

function topFunction() {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
}
